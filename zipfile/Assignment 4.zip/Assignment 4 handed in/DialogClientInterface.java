/**Assignment#4: DialogClientInterface
 *Name: Fr�d�ric Marchand
 *Student Number: 100817579
 **/
public interface  DialogClientInterface {
	public void dialogFinished();
	public void dialogCancelled();
}